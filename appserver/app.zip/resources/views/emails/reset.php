<p>尊敬的 <?=$username?></p>
<p style="padding-left: 30px;">您好, 您刚刚在 <?=$sitename?> 申请了重置密码，请点击下面的链接进行重置：</p>
<p style="padding-left: 30px;"><a href="<?=$link?>"><?=$link?></a></p>
<p style="padding-left: 30px;">此链接只能使用一次, 如果失效请重新申请。</p>
